A sync calls B
A async calls C
B sync calls D, E
C async calls F, G