#  Extractor

Reads the invocations from Cloudwatch Logs.

Writes them into a S3 Bucket.