# Coldstarts

This file is automatically deployed Lambda Function. It changes the env variables of all functions deployed as part of the framework and thus forces their cold starts.