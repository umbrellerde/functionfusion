# Optimizer

Read the invocations from the bucket.

Do some magic to determine the next fusion setup and write an ENV var into the existing function lambdas.